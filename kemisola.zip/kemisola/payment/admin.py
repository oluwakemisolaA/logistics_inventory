from django.contrib import admin
from . models import payment,Subscription

# Register your models here.
admin.site.register(payment)
admin.site.register(Subscription)
