'use strict';

setTimeout(function() {
	$('#messages').fadeOut('slow');
}, 10000);

$('button').click(function() {
	$('#messages').fadeOut('slow');
});








